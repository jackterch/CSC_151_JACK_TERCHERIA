public class Main {
    public static void main(String[] args) {
        FileOperator file_operator = new FileOperator();

        file_operator.main();
    }
}
